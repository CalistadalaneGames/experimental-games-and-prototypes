﻿namespace Dungine.Parser
{
    internal class ParserActions
    {
    }
}
