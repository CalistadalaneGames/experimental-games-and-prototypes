﻿/* ⠉⠕⠏⠽⠗⠊⠛⠓⠞⠼⠃⠼⠚⠼⠃⠼⠚⠁⠏⠗⠑⠞⠞⠽⠉⠕⠕⠇⠏⠗⠕⠛⠗⠁⠍⠁⠝⠙⠉⠁⠇⠊⠎⠞⠁⠙⠁⠇⠁⠝⠑⠛⠁⠍⠑⠎
 * Dungine: A game engine. [https://github.com/CalistadalaneGames/dungine]
 * Version 0.5.x.x
 * (C)2020 A Pretty Cool Program & Calistadalane Games. All rights reserved.
 * Licensed under Apache v2 [https://apache.org/licenses/LICENSE-2.0]
 *
 * FILE: Dungine.Common.GameRule.cs
 * DESC: Defines various game rules.
 * AUTHOR(S): development@aprettycoolprogram.com
 */

namespace Dungine.Common
{
    /// <summary>
    /// Defines the rules of a game.
    /// </summary>
    public class GameRule
    {
        /* This class defines the following message details:
         *
         *  StartingRoom: The starting room of the game (i.e. "0")
         *  EntranceRoom: The entrance room of the game (i.e. "1")
         *      ExitRoom: The exit room of the game (i.e. "2")
         *
         * Please refer to the Dungine documentation for more information.
         */
        public string StartingRoom { get; set; }
        public string EntranceRoom { get; set; }
        public string ExitRoom { get; set; }
    }
}
