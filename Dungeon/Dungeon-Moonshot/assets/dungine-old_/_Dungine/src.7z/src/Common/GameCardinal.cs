﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dungine.Common
{
    public partial class GameCardinal
    {
    }
}
