﻿/* Dungine: A game engine [v0.6.x.x] (https://github.com/CalistadalaneGames/dungine)
 *
 * FILE: Dungine.Common.GameRoom.cs
 * DESCRIPTION: Contains all components of a game.
 * AUTHOR: development@aprettycoolprogram.com
 *
 * This partial class is comprised of:
 *
 *  - Dungine.Common.GameRoom.cs            : Logic
 *  - Dungine.Common.GameRoom.Properties.cs : Property declarations
 *
 * (C)2020 A Pretty Cool Program & Calistadalane Games. All rights reserved.
 * Licensed under Apache v2 (https://apache.org/licenses/LICENSE-2.0)
 *
 * For more information, read the manual (https://github.com/CalistadalaneGames/dungine/doc/manual/dungine-manual.md)
 */

using System.Collections.Generic;

namespace Dungine.Common
{
    /// <summary>
    /// Defines rooms in a game.
    /// </summary>
    public partial class GameRoom
    {
    }
}
