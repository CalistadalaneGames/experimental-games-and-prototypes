﻿/* Dungine: A game engine [v0.6.x.x] (https://github.com/CalistadalaneGames/dungine)
 *
 * FILE: Dungine.Common.GameDetail.cs
 * DESCRIPTION: Contains all details of a game.
 * AUTHOR: development@aprettycoolprogram.com
 *
 * This partial class is comprised of:
 *
 *  - Dungine.Common.GameDetail.cs            : Logic
 *  - Dungine.Common.GameDetail.Properties.cs : Property declarations
 *
 * (C)2020 A Pretty Cool Program & Calistadalane Games. All rights reserved.
 * Licensed under Apache v2 (https://apache.org/licenses/LICENSE-2.0)
 *
 * For more information, read the manual (https://github.com/CalistadalaneGames/dungine/doc/manual/dungine-manual.md)
 */

namespace Dungine.Game
{
    /// <include file='Dungine.Game.Detail.xml' path='class/member[@name="Detail"]/*'/>
    public partial class Detail
    {
        // Logic will go here.
    }
}