﻿# Dungine Changelog

## Version 0.6.x
> The 0.6.x version is a refactor
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.
## Version 0.5.x
> The 0.5.x version of Dungine is used for **Dungeon: The Evil Lair**
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.

## Version 0.4.x
> The 0.4.x version of Dungine is used for **Dungeon: Text Adventure 04**
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.

## Version 0.3.x
> The 0.3.x version of Dungine is used for **Dungeon: Text Adventure 03**
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.

## Version 0.2.x
> The 0.3.x version of Dungine is used for **Dungeon: Text Adventure 01**
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.

## Version 0.1.x
> The 0.3.x version of Dungine is used for **Dungeon: Text Adventure 01**
`INFO` Since Dungine is still in the prototype stage, I won't be keeping track of changes.